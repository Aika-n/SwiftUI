//
//  list08App.swift
//  list08
//
//  Created by it01 on 2021/12/14.
//

import SwiftUI

@main
struct list08App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
