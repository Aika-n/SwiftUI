//
//  ContentView.swift
//  actionSheet09
//
//  Created by it01 on 2021/12/21.
//

// ContentView.swift (OKのみアラート作成例) //

import SwiftUI

struct ContentView: View {
    @State var isError1: Bool = false
    @State var isError2: Bool = false
    @State var isError3: Bool = false
    
    var body: some View {
        VStack(spacing: 100){
            Button(action: {
                self.isError1 = true
            }) {
                Text("OK のみアラート")
        
            }.alert(isPresented: $isError1, content: {
                Alert(title: Text("OK のみアラート"), message: Text("OKのみのアラートを表示します"),
                    dismissButton: .default(Text("OK"), action: { okAction() }))
              } )
            Button(action: {
                self.isError2 = true
            }) {
                Text("OKキャンセルアラート")
        
            }.alert(isPresented: $isError2, content: {
                Alert(title: Text("OKキャンセルアラート"), message: Text("OKとキャンセルのアラートを表示します"),
                      primaryButton: .default(Text("OK"), action: { okAction() }), secondaryButton: .cancel(Text("キャンセル"), action: {}))
              } )
            Button(action: {
                self.isError3 = true
            }) {
                Text("削除アラート")
        
            }.alert(isPresented: $isError3, content: {
                Alert(title: Text("削除アラート"), message: Text("削除アラートを赤文字で表示します"),
                      primaryButton: .destructive(Text("削除"), action: { }),
                      secondaryButton: .cancel(Text("キャンセル"), action: {}))
              } )
        }
      }
}
func okAction(){
    print("OK が押されました")
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

