//
//  actionSheet09App.swift
//  actionSheet09
//
//  Created by it01 on 2021/12/21.
//

import SwiftUI

@main
struct actionSheet09App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
