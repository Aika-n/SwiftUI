//
//  ContentView.swift
//  picker06
//
//  Created by it01 on 2021/11/09.
//

import SwiftUI

struct ContentView: View {
    @State private var selectColor = 0
    let colorViews = [Color.red, Color.green, Color.blue]
    let colorNames = ["赤","緑","青"]
    
    var body: some View {
        VStack {
            Picker(selection: $selectColor, label: Text("色")) {
                Text("赤").tag(0)
                Text("緑").tag(1)
                Text("青").tag(2)
            }
            .pickerStyle(WheelPickerStyle())
            HStack{
                colorViews[selectColor]
                    .frame(width: 50, height: 50, alignment: .center)
                Text("カラー： \(colorNames[selectColor])").frame(width: 100, height: 50
                                                              , alignment: .center)
                
            }
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider
{
    static var previews: some View{
        ContentView()
    }
}
