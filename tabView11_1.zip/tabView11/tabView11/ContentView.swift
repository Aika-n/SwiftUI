//
//  ContentView.swift
//  tabView11
//
//  Created by it01 on 2022/01/11.
//

import SwiftUI

struct ContentView: View {
    @State private var selection = 0
    var body: some View {
        TabView(selection: $selection) { Text("Tab Content 1")
                .tabItem {
                    Image("first")
                    Text("First")
            }
            .tag(1)
            .font(.largeTitle)
            Text("Tab Content 2")
                .tabItem {
                    Image("second")
                    Text("Second")
            }
            .tag(2)
            .font(.largeTitle)
            Text("Tab Content 3")
                .tabItem {
                    Image("third")
                    Text("Third")
            }.tag(3)
            .font(.largeTitle)
        }
} }
   

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
