//
//  tabView11App.swift
//  tabView11
//
//  Created by it01 on 2022/01/11.
//

import SwiftUI

@main
struct tabView11App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
