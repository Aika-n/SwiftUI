//
//  ContentView.swift
//  webView10
//
//  Created by it01 on 2021/12/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        makeWebView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
