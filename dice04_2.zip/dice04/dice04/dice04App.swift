//
//  dice04App.swift
//  dice04
//
//  Created by it01 on 2021/10/26.
//

import SwiftUI

@main
struct dice04App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
