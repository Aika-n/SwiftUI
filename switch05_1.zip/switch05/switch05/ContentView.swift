//
//  ContentView.swift
//  switch05
//
//  Created by it01 on 2021/11/02.
//

import SwiftUI

struct ContentView: View {
    
    @State var r_value = "0"
    @State var iLike = true
    
    var body: some View {
        VStack {
            HStack {
                Spacer()
                Toggle(isOn: $iLike) { Text("表示").font(.largeTitle)
                        .multilineTextAlignment(.leading)
                }
                .fixedSize()
                Spacer()
                if iLike{
                    Text(r_value).font(.largeTitle)
                }else{
                    Text("   ").font(.largeTitle)
                }
                Spacer() }
            HStack {
                Button(action: {
                    // 0 から 9 の整数の乱数を生成する
                    let num = Int.random(in: 0 ... 9)
                    // Int 型を String 型に変換する
                    self.r_value = String(num)
                }) { Text("ランダム値生成")
                        .font(.largeTitle)
                }
            }
        }
    }
    
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }
}
