//
//  switch05App.swift
//  switch05
//
//  Created by it01 on 2021/11/02.
//

import SwiftUI

@main
struct switch05App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
