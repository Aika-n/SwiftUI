//
//  ContentView.swift
//  tabView11
//
//  Created by it01 on 2022/01/11.
//

import SwiftUI

struct ContentView: View {
    @State private var selection = 0
    var body: some View {
        TabView(selection: $selection) {
            VStack{
                Image("gyudon")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                Text("牛丼")
            }
                .tabItem {
                    Image("first")
                    Text("First")
            }
                .tag(1)
                .font(.largeTitle)
            VStack{
                Image("curry")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                Text("カレー")
            }
                .tabItem {
                    Image("second")
                    Text("Second")
            }
                .tag(2)
                .font(.largeTitle)
            VStack{
                Image("ramen")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                Text("ラーメン")
            }
                .tabItem {
                    Image("third")
                    Text("Third")
            }
                .tag(3)
                .font(.largeTitle)
        }
} }
   

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
