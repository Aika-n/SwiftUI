//
//  ContentView.swift
//  buttonTest03
//
//  Created by it01 on 2021/10/19.
//

import SwiftUI

struct ContentView: View {
    //@State の記述で、管理を SwiftUI フレームワークに反映させて値を更新することができるようにする
    @State var labelText = "Hello, World!"
    @State var flag = false
    @State var font = Font.largeTitle
    
    var body: some View {
        VStack { // 垂直方向へ記述順にレイアウトする
            Spacer() // 適切な空白を挿入する
            Text(labelText)
                .font(font)
            
            Spacer()// 適切な空白を挿入する
            Button(action: { // ボタンが押された時の処理はここに記述する
                if(self.flag){
                    self.labelText = "Hello" // flag の値を反転させる
                    self.flag.toggle()
                    self.font = Font.largeTitle
                } else{
                    self.labelText = "World"
                    // flag の値を反転させる
                    self.flag.toggle()
                    self.font = Font.subheadline
                }
            }) {
                Text("ボタン")
                    .font(.largeTitle)
            }
                Spacer()// 適切な空白を挿入する
            
            
        }
    }
    struct ContentView_Previews: PreviewProvider { static var previews: some View {
        ContentView()
    }}
}
