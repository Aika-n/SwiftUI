//
//  buttonTest03App.swift
//  buttonTest03
//
//  Created by it01 on 2021/10/19.
//

import SwiftUI

@main
struct buttonTest03App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
