//
//  picker06App.swift
//  picker06
//
//  Created by it01 on 2021/11/09.
//

import SwiftUI

@main
struct picker06App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
