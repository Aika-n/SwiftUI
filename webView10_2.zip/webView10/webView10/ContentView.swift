//
//  ContentView.swift
//  webView10
//
//  Created by it01 on 2021/12/21.
//

import SwiftUI

struct ContentView: View {
    @State var isError1: Bool = false
    var body: some View {
        //Sheet表示
        Button(action: {
            self.isError1 = true
        }) {
            Text("SheetでYahoo!を表示する")
            }.sheet(isPresented: $isError1 ){
                makeWebView()
            }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
