//
//  ContentView.swift
//  list08
//
//  Created by it01 on 2021/12/14.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        let items:[String] = ["弁当", "カレー", "牛丼", "パン", "ラーメン"]
        List(0..<5) { item in
            Text(items[item])
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
