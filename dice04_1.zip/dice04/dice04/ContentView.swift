//
//  ContentView.swift
//  dice04
//
//  Created by it01 on 2021/10/26.
//

import SwiftUI

struct ContentView: View {
    //@State の記述で、管理を SwiftUI フレームワークに反映させて値を更新することができるようにする
    @State var labelText = "0"
    @State var font = Font.largeTitle
    @State var color = Color.red
    
    var body: some View {
        VStack {
            Text(labelText)
                .padding()
                .font(.system(size: 200))
                .foregroundColor(color)
            
//            Spacer() // 適切な空白を挿入する
            
            Button(action: {
                let num = Int.random(in: 1 ... 6)
                var strnum = String(num)
                self.labelText = strnum
            }) {
                Text("サイコロを振る")
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
